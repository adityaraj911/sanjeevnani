Sprint 3: GPS ambulance, nearest hospital, driver location, hospital alert.
Replace these 4 files in your project (same paths as before):
  app/src/main/java/com/sanjeevani/app/data/AppRepository.kt
  app/src/main/java/com/sanjeevani/app/ui/common/Common.kt
  app/src/main/java/com/sanjeevani/app/ui/user/UserApp.kt
  app/src/main/java/com/sanjeevani/app/ui/provider/ProviderApp.kt
Add in app/build.gradle.kts dependencies, then Sync:
  implementation("com.google.android.gms:play-services-location:21.3.0")
No changes to firestore.rules or Firebase plan needed (no Cloud Functions yet).

HOW TO TEST (3 accounts, use 3 Firebase test numbers, sign out/in on one emulator):
1) Hospital account: sign up as Provider > Hospital. In Firestore Console set providers/<uid>.verified = true.
   In app: Profile > name, phone > Use my current location > turn on 24x7 and ICU > Save profile.
2) Ambulance account: sign up as Provider > Ambulance operator. Set verified = true in Firestore.
   Profile > name, phone > Save > turn Available ON. Requests tab > Allow location.
3) Patient account: Ambulance tab > Share my location > pick hospital > Request.
4) Switch to the ambulance account > Requests > see distance > Accept > Open in Maps.
5) Switch to the hospital account > Requests: the incoming ambulance appears.
Emulator location: the "..." button on the emulator toolbar > Location > set a point > Send.
