package com.sanjeevani.app.ui.user

import android.Manifest
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import com.sanjeevani.app.ui.common.LocationHelper
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sanjeevani.app.data.*
import com.sanjeevani.app.ui.common.dial
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

@Composable
fun UserApp(profile: UserProfile, repo: AppRepository, onSignOut: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf("Home" to Icons.Default.Home, "Medicines" to Icons.Default.Search,
        "Ambulance" to Icons.Default.Warning, "Profile" to Icons.Default.Person)
    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) }, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab { tab = it }
                1 -> MedicineTab(repo)
                2 -> AmbulanceTab(profile, repo)
                else -> UserProfileTab(profile, onSignOut)
            }
        }
    }
}

@Composable
private fun HomeTab(onGo: (Int) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Need help now?", style = MaterialTheme.typography.headlineMedium)
        Button({ ctx.dial("108") }, Modifier.fillMaxWidth().height(72.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) {
            Text("Call ambulance (108)", style = MaterialTheme.typography.titleLarge)
        }
        OutlinedButton({ ctx.dial("112") }, Modifier.fillMaxWidth()) { Text("Call emergency (112)") }
        HorizontalDivider()
        Text("Through Sanjeevani", style = MaterialTheme.typography.titleMedium)
        Card({ onGo(2) }, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Request an ambulance", style = MaterialTheme.typography.titleMedium)
                Text("Nearby operators see your request and can accept it.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        Card({ onGo(1) }, Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Find a medicine", style = MaterialTheme.typography.titleMedium)
                Text("Search pharmacies that have it in stock.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        Text("Sanjeevani helps you reach nearby providers. It cannot guarantee availability or arrival time. " +
            "In a life-threatening emergency, call 108 or 112.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MedicineTab(repo: AppRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<InventoryItem>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    fun search() {
        if (q.isBlank()) return
        busy = true; error = null
        scope.launch {
            runCatching { repo.searchMedicines(q.trim().lowercase()) }
                .onSuccess { results = it }
                .onFailure { error = "Could not search. Check your internet and try again." }
            busy = false
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Find a medicine", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, label = { Text("Medicine name") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() }))
            Button({ search() }, Modifier.align(androidx.compose.ui.Alignment.CenterVertically), enabled = !busy) { Text("Search") }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        val r = results
        if (r != null && r.isEmpty() && !busy) Text("No pharmacy has \"${q.trim()}\" listed in stock yet. Try the start of the name, for example \"para\".")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(r ?: emptyList()) { it ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(it.name, style = MaterialTheme.typography.titleMedium)
                        Text("Rs ${"%.2f".format(it.price)}  |  ${it.quantity} in stock")
                        Text(it.providerName.ifBlank { "Pharmacy" }, style = MaterialTheme.typography.bodyMedium)
                        if (it.requiresPrescription) Text("Prescription required", color = MaterialTheme.colorScheme.secondary,
                            style = MaterialTheme.typography.labelLarge)
                        if (it.providerPhone.isNotBlank()) TextButton({ ctx.dial(it.providerPhone) }) { Text("Call pharmacy") }
                    }
                }
            }
        }
    }
}

@Composable
private fun AmbulanceTab(profile: UserProfile, repo: AppRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val active by remember(profile.uid) { repo.myActiveRequest(profile.uid).catch { emit(null) } }
        .collectAsStateWithLifecycle(initialValue = null)
    var loc by remember { mutableStateOf<Location?>(null) }
    var locMsg by remember { mutableStateOf<String?>(null) }
    var hospitals by remember { mutableStateOf<List<Hospital>>(emptyList()) }
    var chosen by remember { mutableStateOf<Hospital?>(null) }
    var note by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun fetchLocation() {
        locMsg = "Getting your exact location..."
        scope.launch {
            val l = runCatching { LocationHelper.current(ctx) }.getOrNull()
            if (l == null) { locMsg = "Could not get your location. Turn on GPS and try again."; return@launch }
            loc = l; locMsg = null
            runCatching { repo.nearbyHospitals(l.latitude, l.longitude) }
                .onSuccess { hospitals = it; chosen = it.firstOrNull() }
                .onFailure { locMsg = "Location found, but hospitals could not be loaded." }
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) fetchLocation()
        else locMsg = "Location permission is needed to send your exact location to the ambulance."
    }
    LaunchedEffect(active == null) {
        if (active == null && loc == null && LocationHelper.hasPermission(ctx)) fetchLocation()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ambulance", style = MaterialTheme.typography.headlineSmall)
        Button({ ctx.dial("108") }, Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) { Text("Call 108 now") }
        val a = active
        if (a != null) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (a.status == "waiting") {
                        Text("Looking for an operator", style = MaterialTheme.typography.titleMedium)
                        Text("Your exact location was sent to nearby verified operators. If it is urgent, do not wait: call 108.")
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    } else {
                        Text("Accepted by ${a.providerName.ifBlank { "an operator" }}", style = MaterialTheme.typography.titleMedium)
                        Text("The operator has your exact location and is on the way.")
                        if (a.providerPhone.isNotBlank()) Button({ ctx.dial(a.providerPhone) }) { Text("Call operator") }
                    }
                    if (a.hospitalName.isNotBlank()) Text("Going to: ${a.hospitalName}", style = MaterialTheme.typography.bodyMedium)
                    TextButton({ scope.launch { runCatching { repo.cancelRequest(a.id) } } }) { Text("Cancel request") }
                }
            }
        } else {
            val l = loc
            if (l == null) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Share your location", style = MaterialTheme.typography.titleMedium)
                        Text("Your exact location is sent automatically to the ambulance operator who accepts, and nobody else.")
                        Button({ permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) {
                            Text("Share my location")
                        }
                        locMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            } else {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Location captured (accuracy ${l.accuracy.toInt()} m)", Modifier.weight(1f))
                        TextButton({ fetchLocation() }) { Text("Refresh") }
                    }
                }
                Text("Nearest hospitals", style = MaterialTheme.typography.titleMedium)
                if (hospitals.isEmpty()) Text("No verified hospital found nearby yet. You can still request an ambulance; the operator will take you to the nearest hospital.",
                    style = MaterialTheme.typography.bodySmall)
                hospitals.take(5).forEachIndexed { i, h ->
                    Card({ chosen = h }, Modifier.fillMaxWidth(),
                        border = if (chosen?.id == h.id) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null) {
                        Column(Modifier.padding(12.dp)) {
                            Row {
                                Text(h.name, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                                if (i == 0) Text("Best match", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.labelLarge)
                            }
                            Text("${"%.1f".format(h.distanceKm)} km | ${if (h.open24x7) "24x7 emergency" else "Not 24x7"} | ${if (h.icuAvailable) "ICU available" else "ICU not available"}",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Patient condition (short)") })
                Button({
                    busy = true; error = null
                    scope.launch {
                        runCatching { repo.createRequest(profile.uid, profile.phone, note, l.latitude, l.longitude, chosen) }
                            .onFailure { error = "Could not send the request. Check your internet and try again." }
                        busy = false
                    }
                }, Modifier.fillMaxWidth(), enabled = !busy) {
                    Text(if (busy) "Sending..." else "Request ambulance with my location")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Text("Hospital suggestions use the information hospitals have entered. You or the driver can choose a different hospital. In a serious emergency, call 108.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun UserProfileTab(profile: UserProfile, onSignOut: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Profile", style = MaterialTheme.typography.headlineSmall)
        Text("Phone: ${profile.phone}")
        Text("Role: Patient / family", style = MaterialTheme.typography.bodyMedium)
        Text("Your phone number is shared only with the operator who accepts your request.",
            style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.weight(1f))
        OutlinedButton(onSignOut, Modifier.fillMaxWidth()) { Text("Sign out") }
    }
}
