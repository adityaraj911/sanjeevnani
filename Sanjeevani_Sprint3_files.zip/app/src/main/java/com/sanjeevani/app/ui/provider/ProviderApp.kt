package com.sanjeevani.app.ui.provider

import android.Manifest
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import com.sanjeevani.app.ui.common.LocationHelper
import com.sanjeevani.app.ui.common.distanceKm
import com.sanjeevani.app.ui.common.openMap
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sanjeevani.app.data.*
import com.sanjeevani.app.ui.common.dial
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

@Composable
fun ProviderApp(profile: UserProfile, repo: AppRepository, onSignOut: () -> Unit) {
    var pp by remember { mutableStateOf<ProviderProfile?>(null) }
    var failed by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        runCatching { repo.getProvider(profile.uid) }.onSuccess { pp = it; failed = false }.onFailure { failed = true }
    }
    val p = pp
    if (p == null) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            if (failed) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Could not load your profile.", color = MaterialTheme.colorScheme.error)
                Button({ reload++ }) { Text("Retry") }
            } else CircularProgressIndicator()
        }
        return
    }
    val items = listOf("Requests" to Icons.Default.Notifications, "Stock" to Icons.Default.List, "Profile" to Icons.Default.Person)
    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) }, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> RequestsTab(p, profile, repo)
                1 -> StockTab(p, profile, repo)
                else -> ProviderProfileTab(p, profile, repo, onChanged = { reload++ }, onSignOut = onSignOut)
            }
        }
    }
}

@Composable
private fun Notice(text: String) {
    Card(Modifier.fillMaxWidth()) { Text(text, Modifier.padding(16.dp)) }
}

@Composable
private fun RequestsTab(pp: ProviderProfile, profile: UserProfile, repo: AppRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    var myLoc by remember { mutableStateOf<Location?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) scope.launch { myLoc = runCatching { LocationHelper.current(ctx) }.getOrNull() }
    }
    LaunchedEffect(Unit) {
        if (LocationHelper.hasPermission(ctx)) myLoc = runCatching { LocationHelper.current(ctx) }.getOrNull()
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Requests", style = MaterialTheme.typography.headlineSmall)
        if (!pp.verified) { Notice("Verification pending. Our team will review your licence. You will receive requests once approved."); return }
        if (pp.type == ProviderType.HOSPITAL.name) {
            val incoming by remember(profile.uid) { repo.incomingFor(profile.uid).catch { emit(emptyList()) } }
                .collectAsStateWithLifecycle(emptyList())
            Text("Ambulances heading to your hospital (${incoming.size})", style = MaterialTheme.typography.titleMedium)
            if (incoming.isEmpty()) Text("No ambulance is heading to your hospital right now.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(incoming) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Patient on the way", style = MaterialTheme.typography.titleSmall)
                            if (r.note.isNotBlank()) Text("Condition: ${r.note}")
                            Text("Ambulance: ${r.providerName.ifBlank { "operator" }}")
                            if (r.providerPhone.isNotBlank()) Button({ ctx.dial(r.providerPhone) }) { Text("Call ambulance") }
                        }
                    }
                }
            }
            return
        }
        if (pp.type != ProviderType.AMBULANCE.name) {
            Notice("Ambulance requests are shown to ambulance operators. Use the Stock tab to list your medicines."); return
        }
        if (!pp.available) { Notice("You are offline. Turn on availability in the Profile tab to see requests."); return }
        val waiting by remember { repo.waitingRequests().catch { emit(emptyList()) } }.collectAsStateWithLifecycle(emptyList())
        val mine by remember(profile.uid) { repo.acceptedBy(profile.uid).catch { emit(emptyList()) } }.collectAsStateWithLifecycle(emptyList())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (pp.name.isBlank()) Text("Add your business name and phone in Profile before accepting.", color = MaterialTheme.colorScheme.error)
        if (myLoc == null) OutlinedButton({ permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) {
            Text("Allow location to see distances")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (mine.isNotEmpty()) item { Text("Your active requests", style = MaterialTheme.typography.titleMedium) }
            items(mine) { r ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Patient location is live", style = MaterialTheme.typography.titleSmall)
                        if (r.note.isNotBlank()) Text(r.note)
                        if (r.hospitalName.isNotBlank()) Text("Destination: ${r.hospitalName}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({ ctx.openMap(r.lat, r.lng, "Patient") }) { Text("Patient location") }
                            if (r.hospitalName.isNotBlank() && r.hospitalLat != 0.0)
                                OutlinedButton({ ctx.openMap(r.hospitalLat, r.hospitalLng, r.hospitalName) }) { Text("Hospital") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton({ ctx.dial(r.userPhone) }) { Text("Call patient") }
                            OutlinedButton({ scope.launch { runCatching { repo.completeRequest(r.id) } } }) { Text("Mark completed") }
                        }
                    }
                }
            }
            item { Text("New requests (${waiting.size})", style = MaterialTheme.typography.titleMedium) }
            if (waiting.isEmpty()) item { Text("No waiting requests right now.", style = MaterialTheme.typography.bodyMedium) }
            items(waiting) { r ->
                val ml = myLoc
                val dist = if (ml != null) "%.1f km away".format(distanceKm(ml.latitude, ml.longitude, r.lat, r.lng)) else "Distance unknown"
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Live location | $dist", style = MaterialTheme.typography.titleSmall)
                        if (r.note.isNotBlank()) Text(r.note)
                        if (r.hospitalName.isNotBlank()) Text("Hospital chosen: ${r.hospitalName}", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({
                                error = null
                                scope.launch {
                                    runCatching { repo.acceptRequest(r.id, profile.uid, pp.name, pp.phone) }
                                        .onFailure { error = "This request was already taken or could not be accepted." }
                                }
                            }, enabled = pp.name.isNotBlank()) { Text("Accept") }
                            OutlinedButton({ ctx.openMap(r.lat, r.lng, "Patient") }) { Text("Open in Maps") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StockTab(pp: ProviderProfile, profile: UserProfile, repo: AppRepository) {
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<InventoryItem?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Stock", style = MaterialTheme.typography.headlineSmall)
        if (!pp.verified) { Notice("You can list stock after your licence is verified."); return }
        if (pp.name.isBlank()) { Notice("Add your business name and phone in the Profile tab first, so patients can see who has the medicine."); return }
        val items by remember(profile.uid) { repo.myItems(profile.uid).catch { emit(emptyList()) } }.collectAsStateWithLifecycle(emptyList())
        Button({ editing = null; showDialog = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add item") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (items.isEmpty()) Text("No items yet. Add the medicines you have in stock.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items.sortedBy { it.name.lowercase() }) { it ->
                Card({ editing = it; showDialog = true }, Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(it.name, style = MaterialTheme.typography.titleSmall)
                            Text("Rs ${"%.2f".format(it.price)}  |  ${it.quantity} in stock" + if (it.requiresPrescription) "  |  Rx" else "",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton({ scope.launch { runCatching { repo.deleteItem(it.id) }.onFailure { error = "Could not delete." } } }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete ${it.name}")
                        }
                    }
                }
            }
        }
    }
    if (showDialog) ItemDialog(editing, onDismiss = { showDialog = false }) { name, qty, price, rx ->
        scope.launch {
            runCatching {
                repo.saveItem(InventoryItem(editing?.id ?: "", name, qty, price, rx, profile.uid, pp.name, pp.phone))
            }.onFailure { error = "Could not save. Check your internet." }
        }
        showDialog = false
    }
}

@Composable
private fun ItemDialog(item: InventoryItem?, onDismiss: () -> Unit, onSave: (String, Int, Double, Boolean) -> Unit) {
    var name by remember { mutableStateOf(item?.name ?: "") }
    var qty by remember { mutableStateOf(item?.quantity?.toString() ?: "") }
    var price by remember { mutableStateOf(item?.price?.toString() ?: "") }
    var rx by remember { mutableStateOf(item?.requiresPrescription ?: false) }
    val q = qty.toIntOrNull(); val pr = price.toDoubleOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (item == null) "Add item" else "Edit item") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Medicine name") }, singleLine = true)
                OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, label = { Text("Quantity in stock") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(price, { price = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Price (Rs)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(rx, { rx = it }); Spacer(Modifier.width(8.dp)); Text("Prescription required")
                }
            }
        },
        confirmButton = {
            TextButton({ onSave(name, q ?: 0, pr ?: 0.0, rx) }, enabled = name.isNotBlank() && q != null && pr != null) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ProviderProfileTab(pp: ProviderProfile, profile: UserProfile, repo: AppRepository, onChanged: () -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember(pp) { mutableStateOf(pp.name) }
    var phone by remember(pp) { mutableStateOf(pp.phone.ifBlank { profile.phone.removePrefix("+91") }) }
    var address by remember(pp) { mutableStateOf(pp.address) }
    var lat by remember(pp) { mutableStateOf(pp.lat) }
    var lng by remember(pp) { mutableStateOf(pp.lng) }
    var open24 by remember(pp) { mutableStateOf(pp.open24x7) }
    var icu by remember(pp) { mutableStateOf(pp.icuAvailable) }
    var msg by remember { mutableStateOf<String?>(null) }
    fun grab() {
        scope.launch {
            val l = runCatching { LocationHelper.current(ctx) }.getOrNull()
            if (l != null) { lat = l.latitude; lng = l.longitude; msg = "Location captured. Tap Save profile." }
            else msg = "Could not get your location. Turn on GPS and try again."
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) grab() else msg = "Location permission is needed."
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Profile", style = MaterialTheme.typography.headlineSmall)
        Text((profile.providerType?.label ?: "Provider") + if (pp.verified) "  |  Verified" else "  |  Verification pending",
            style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Business / provider name") }, singleLine = true)
        OutlinedTextField(phone, { phone = it }, Modifier.fillMaxWidth(), label = { Text("Contact phone (shown to patients)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        OutlinedTextField(address, { address = it }, Modifier.fillMaxWidth(), label = { Text("Address") })
        val la = lat; val ln = lng
        Text(if (la != null && ln != null) "Location saved: ${"%.4f".format(la)}, ${"%.4f".format(ln)}" else "No location yet. Drivers and patients need it.",
            style = MaterialTheme.typography.bodySmall)
        OutlinedButton({
            if (LocationHelper.hasPermission(ctx)) grab()
            else permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }, Modifier.fillMaxWidth()) { Text("Use my current location") }
        if (pp.type == ProviderType.HOSPITAL.name) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("24x7 emergency available"); Switch(open24, { open24 = it })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("ICU bed available now"); Switch(icu, { icu = it })
            }
            Text("Keep these updated. Patients are guided by them.", style = MaterialTheme.typography.bodySmall)
        }
        Button({
            scope.launch {
                runCatching { repo.saveProviderProfile(profile.uid, name, phone, address, lat, lng, open24, icu) }
                    .onSuccess { msg = "Saved."; onChanged() }.onFailure { msg = "Could not save. Check your internet." }
            }
        }, Modifier.fillMaxWidth(), enabled = name.isNotBlank()) { Text("Save profile") }
        msg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        if (pp.verified) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Available for requests")
            Switch(pp.available, { on -> scope.launch { runCatching { repo.setAvailable(profile.uid, on) }.onSuccess { onChanged() } } })
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onSignOut, Modifier.fillMaxWidth()) { Text("Sign out") }
    }
}
