package com.sanjeevani.app.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

data class InventoryItem(
    val id: String = "", val name: String, val quantity: Int, val price: Double,
    val requiresPrescription: Boolean, val providerId: String, val providerName: String, val providerPhone: String
)

data class AmbulanceRequest(
    val id: String, val userId: String, val userPhone: String, val address: String, val note: String,
    val status: String, val providerId: String, val providerName: String, val providerPhone: String, val createdAt: Long,
    val lat: Double = 0.0, val lng: Double = 0.0, val hospitalId: String = "", val hospitalName: String = "",
    val hospitalLat: Double = 0.0, val hospitalLng: Double = 0.0
)

data class ProviderProfile(
    val name: String, val phone: String, val address: String,
    val verified: Boolean, val available: Boolean, val type: String,
    val lat: Double? = null, val lng: Double? = null, val open24x7: Boolean = false, val icuAvailable: Boolean = false
)

data class Hospital(
    val id: String, val name: String, val phone: String, val address: String, val lat: Double, val lng: Double,
    val open24x7: Boolean, val icuAvailable: Boolean, val distanceKm: Double
)

private fun <T> Query.watch(map: (DocumentSnapshot) -> T): Flow<List<T>> = callbackFlow {
    val reg = addSnapshotListener { s, e ->
        if (e != null) { close(e); return@addSnapshotListener }
        if (s != null) trySend(s.documents.map(map))
    }
    awaitClose { reg.remove() }
}

private fun DocumentSnapshot.toItem() = InventoryItem(
    id, getString("name") ?: "", (getLong("quantity") ?: 0L).toInt(), getDouble("price") ?: 0.0,
    getBoolean("requiresPrescription") ?: false, getString("providerId") ?: "",
    getString("providerName") ?: "", getString("providerPhone") ?: ""
)

private fun DocumentSnapshot.toRequest() = AmbulanceRequest(
    id, getString("userId") ?: "", getString("userPhone") ?: "", getString("address") ?: "",
    getString("note") ?: "", getString("status") ?: "", getString("providerId") ?: "",
    getString("providerName") ?: "", getString("providerPhone") ?: "",
    getTimestamp("createdAt")?.toDate()?.time ?: 0L,
    lat = getDouble("lat") ?: 0.0, lng = getDouble("lng") ?: 0.0, hospitalId = getString("hospitalId") ?: "",
    hospitalName = getString("hospitalName") ?: "", hospitalLat = getDouble("hospitalLat") ?: 0.0,
    hospitalLng = getDouble("hospitalLng") ?: 0.0
)

class AppRepository(private val db: FirebaseFirestore = FirebaseFirestore.getInstance()) {

    // ---------- provider profile ----------
    suspend fun getProvider(uid: String): ProviderProfile {
        val d = db.collection("providers").document(uid).get().await()
        return ProviderProfile(
            d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("address") ?: "",
            d.getBoolean("verified") ?: false, d.getBoolean("available") ?: false, d.getString("type") ?: "",
            d.getDouble("lat"), d.getDouble("lng"), d.getBoolean("open24x7") ?: false, d.getBoolean("icuAvailable") ?: false
        )
    }

    suspend fun saveProviderProfile(
        uid: String, name: String, phone: String, address: String,
        lat: Double?, lng: Double?, open24x7: Boolean, icuAvailable: Boolean
    ) {
        val m = mutableMapOf<String, Any>(
            "name" to name.trim(), "phone" to phone.trim(), "address" to address.trim(),
            "open24x7" to open24x7, "icuAvailable" to icuAvailable
        )
        if (lat != null && lng != null) { m["lat"] = lat; m["lng"] = lng }
        db.collection("providers").document(uid).update(m).await()
    }

    suspend fun setAvailable(uid: String, available: Boolean) {
        db.collection("providers").document(uid).update("available", available).await()
    }

    // ---------- inventory ----------
    fun myItems(uid: String): Flow<List<InventoryItem>> =
        db.collection("inventory").whereEqualTo("providerId", uid).watch { it.toItem() }

    suspend fun saveItem(item: InventoryItem) {
        val data = hashMapOf<String, Any>(
            "name" to item.name.trim(), "nameLower" to item.name.trim().lowercase(),
            "quantity" to item.quantity, "price" to item.price,
            "requiresPrescription" to item.requiresPrescription, "providerId" to item.providerId,
            "providerName" to item.providerName, "providerPhone" to item.providerPhone,
            "updatedAt" to Timestamp.now()
        )
        val col = db.collection("inventory")
        if (item.id.isEmpty()) col.add(data).await() else col.document(item.id).set(data).await()
    }

    suspend fun deleteItem(id: String) { db.collection("inventory").document(id).delete().await() }

    /** Prefix search on the lower-cased medicine name, in-stock items only. */
    suspend fun searchMedicines(q: String): List<InventoryItem> {
        val s = db.collection("inventory")
            .whereGreaterThanOrEqualTo("nameLower", q).whereLessThan("nameLower", q + "\uf8ff")
            .limit(30).get().await()
        return s.documents.map { it.toItem() }.filter { it.quantity > 0 }
    }

    // ---------- ambulance requests ----------
    suspend fun createRequest(uid: String, phone: String, note: String, lat: Double, lng: Double, hospital: Hospital?) {
        val m = hashMapOf<String, Any>(
            "userId" to uid, "userPhone" to phone, "address" to "GPS location", "note" to note.trim(),
            "lat" to lat, "lng" to lng, "status" to "waiting", "createdAt" to Timestamp.now()
        )
        if (hospital != null) {
            m["hospitalId"] = hospital.id; m["hospitalName"] = hospital.name
            m["hospitalLat"] = hospital.lat; m["hospitalLng"] = hospital.lng
        }
        db.collection("requests").add(m).await()
    }

    fun myActiveRequest(uid: String): Flow<AmbulanceRequest?> =
        db.collection("requests").whereEqualTo("userId", uid).whereIn("status", listOf("waiting", "accepted"))
            .watch { it.toRequest() }.map { l -> l.maxByOrNull { it.createdAt } }

    suspend fun cancelRequest(id: String) { db.collection("requests").document(id).update("status", "cancelled").await() }

    fun waitingRequests(): Flow<List<AmbulanceRequest>> =
        db.collection("requests").whereEqualTo("status", "waiting").watch { it.toRequest() }
            .map { l -> l.sortedByDescending { it.createdAt } }

    fun acceptedBy(uid: String): Flow<List<AmbulanceRequest>> =
        db.collection("requests").whereEqualTo("providerId", uid).whereEqualTo("status", "accepted")
            .watch { it.toRequest() }

    /** Transaction: only the first provider to accept wins. */
    suspend fun acceptRequest(id: String, uid: String, name: String, phone: String) {
        val ref = db.collection("requests").document(id)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            if (snap.getString("status") != "waiting") throw IllegalStateException("taken")
            tx.update(ref, mapOf(
                "status" to "accepted", "providerId" to uid, "providerName" to name,
                "providerPhone" to phone, "acceptedAt" to Timestamp.now()
            ))
            null
        }.await()
    }

    /** Verified hospitals within 60 km, best match first: 24x7 + ICU, then 24x7, then the rest; ties by distance. */
    suspend fun nearbyHospitals(lat: Double, lng: Double): List<Hospital> {
        val snap = db.collection("providers").whereEqualTo("type", "HOSPITAL").whereEqualTo("verified", true).get().await()
        return snap.documents.mapNotNull { d ->
            val hl = d.getDouble("lat") ?: return@mapNotNull null
            val hg = d.getDouble("lng") ?: return@mapNotNull null
            Hospital(d.id, d.getString("name") ?: "Hospital", d.getString("phone") ?: "", d.getString("address") ?: "",
                hl, hg, d.getBoolean("open24x7") ?: false, d.getBoolean("icuAvailable") ?: false,
                com.sanjeevani.app.ui.common.distanceKm(lat, lng, hl, hg))
        }.filter { it.distanceKm <= 60.0 }
            .sortedWith(compareBy<Hospital>({ (if (it.open24x7) 0 else 2) + (if (it.icuAvailable) 0 else 1) }, { it.distanceKm }))
    }

    /** Ambulances that accepted a patient and are heading to this hospital. */
    fun incomingFor(hospitalId: String): Flow<List<AmbulanceRequest>> =
        db.collection("requests").whereEqualTo("hospitalId", hospitalId).whereEqualTo("status", "accepted")
            .watch { it.toRequest() }

    suspend fun completeRequest(id: String) { db.collection("requests").document(id).update("status", "completed").await() }
}
