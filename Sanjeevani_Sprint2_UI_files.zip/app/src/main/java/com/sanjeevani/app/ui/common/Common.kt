package com.sanjeevani.app.ui.common

import android.content.Context
import android.content.Intent
import android.net.Uri

fun Context.dial(number: String) {
    if (number.isBlank()) return
    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
}
