package com.sanjeevani.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sanjeevani.app.data.AppRepository
import com.sanjeevani.app.data.Role
import com.sanjeevani.app.ui.auth.*
import com.sanjeevani.app.ui.provider.ProviderApp
import com.sanjeevani.app.ui.theme.SanjeevaniTheme
import com.sanjeevani.app.ui.user.UserApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SanjeevaniTheme {
                Surface(Modifier.fillMaxSize().safeDrawingPadding()) {
                    val vm: AuthViewModel = viewModel()
                    val repo = remember { AppRepository() }
                    val session by vm.session.collectAsStateWithLifecycle()
                    val ui by vm.ui.collectAsStateWithLifecycle()
                    when (val s = session) {
                        Session.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                        Session.SignedOut -> LoginScreen(ui, vm::sendCode, vm::verifyCode)
                        is Session.NeedsRole -> RoleScreen(ui.error, vm::chooseRole)
                        is Session.Ready ->
                            if (s.profile.role == Role.USER) UserApp(s.profile, repo, vm::signOut)
                            else ProviderApp(s.profile, repo, vm::signOut)
                    }
                }
            }
        }
    }
}
