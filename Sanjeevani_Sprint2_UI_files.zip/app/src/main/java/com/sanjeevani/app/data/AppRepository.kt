package com.sanjeevani.app.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

data class InventoryItem(
    val id: String = "", val name: String, val quantity: Int, val price: Double,
    val requiresPrescription: Boolean, val providerId: String, val providerName: String, val providerPhone: String
)

data class AmbulanceRequest(
    val id: String, val userId: String, val userPhone: String, val address: String, val note: String,
    val status: String, val providerId: String, val providerName: String, val providerPhone: String, val createdAt: Long
)

data class ProviderProfile(
    val name: String, val phone: String, val address: String,
    val verified: Boolean, val available: Boolean, val type: String
)

private fun <T> Query.watch(map: (DocumentSnapshot) -> T): Flow<List<T>> = callbackFlow {
    val reg = addSnapshotListener { s, e ->
        if (e != null) { close(e); return@addSnapshotListener }
        if (s != null) trySend(s.documents.map(map))
    }
    awaitClose { reg.remove() }
}

private fun DocumentSnapshot.toItem() = InventoryItem(
    id, getString("name") ?: "", (getLong("quantity") ?: 0L).toInt(), getDouble("price") ?: 0.0,
    getBoolean("requiresPrescription") ?: false, getString("providerId") ?: "",
    getString("providerName") ?: "", getString("providerPhone") ?: ""
)

private fun DocumentSnapshot.toRequest() = AmbulanceRequest(
    id, getString("userId") ?: "", getString("userPhone") ?: "", getString("address") ?: "",
    getString("note") ?: "", getString("status") ?: "", getString("providerId") ?: "",
    getString("providerName") ?: "", getString("providerPhone") ?: "",
    getTimestamp("createdAt")?.toDate()?.time ?: 0L
)

class AppRepository(private val db: FirebaseFirestore = FirebaseFirestore.getInstance()) {

    // ---------- provider profile ----------
    suspend fun getProvider(uid: String): ProviderProfile {
        val d = db.collection("providers").document(uid).get().await()
        return ProviderProfile(
            d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("address") ?: "",
            d.getBoolean("verified") ?: false, d.getBoolean("available") ?: false, d.getString("type") ?: ""
        )
    }

    suspend fun saveProviderProfile(uid: String, name: String, phone: String, address: String) {
        db.collection("providers").document(uid)
            .update(mapOf("name" to name.trim(), "phone" to phone.trim(), "address" to address.trim())).await()
    }

    suspend fun setAvailable(uid: String, available: Boolean) {
        db.collection("providers").document(uid).update("available", available).await()
    }

    // ---------- inventory ----------
    fun myItems(uid: String): Flow<List<InventoryItem>> =
        db.collection("inventory").whereEqualTo("providerId", uid).watch { it.toItem() }

    suspend fun saveItem(item: InventoryItem) {
        val data = hashMapOf<String, Any>(
            "name" to item.name.trim(), "nameLower" to item.name.trim().lowercase(),
            "quantity" to item.quantity, "price" to item.price,
            "requiresPrescription" to item.requiresPrescription, "providerId" to item.providerId,
            "providerName" to item.providerName, "providerPhone" to item.providerPhone,
            "updatedAt" to Timestamp.now()
        )
        val col = db.collection("inventory")
        if (item.id.isEmpty()) col.add(data).await() else col.document(item.id).set(data).await()
    }

    suspend fun deleteItem(id: String) { db.collection("inventory").document(id).delete().await() }

    /** Prefix search on the lower-cased medicine name, in-stock items only. */
    suspend fun searchMedicines(q: String): List<InventoryItem> {
        val s = db.collection("inventory")
            .whereGreaterThanOrEqualTo("nameLower", q).whereLessThan("nameLower", q + "\uf8ff")
            .limit(30).get().await()
        return s.documents.map { it.toItem() }.filter { it.quantity > 0 }
    }

    // ---------- ambulance requests ----------
    suspend fun createRequest(uid: String, phone: String, address: String, note: String) {
        db.collection("requests").add(
            hashMapOf<String, Any>(
                "userId" to uid, "userPhone" to phone, "address" to address.trim(), "note" to note.trim(),
                "status" to "waiting", "createdAt" to Timestamp.now()
            )
        ).await()
    }

    fun myActiveRequest(uid: String): Flow<AmbulanceRequest?> =
        db.collection("requests").whereEqualTo("userId", uid).whereIn("status", listOf("waiting", "accepted"))
            .watch { it.toRequest() }.map { l -> l.maxByOrNull { it.createdAt } }

    suspend fun cancelRequest(id: String) { db.collection("requests").document(id).update("status", "cancelled").await() }

    fun waitingRequests(): Flow<List<AmbulanceRequest>> =
        db.collection("requests").whereEqualTo("status", "waiting").watch { it.toRequest() }
            .map { l -> l.sortedByDescending { it.createdAt } }

    fun acceptedBy(uid: String): Flow<List<AmbulanceRequest>> =
        db.collection("requests").whereEqualTo("providerId", uid).whereEqualTo("status", "accepted")
            .watch { it.toRequest() }

    /** Transaction: only the first provider to accept wins. */
    suspend fun acceptRequest(id: String, uid: String, name: String, phone: String) {
        val ref = db.collection("requests").document(id)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            if (snap.getString("status") != "waiting") throw IllegalStateException("taken")
            tx.update(ref, mapOf(
                "status" to "accepted", "providerId" to uid, "providerName" to name,
                "providerPhone" to phone, "acceptedAt" to Timestamp.now()
            ))
            null
        }.await()
    }

    suspend fun completeRequest(id: String) { db.collection("requests").document(id).update("status", "completed").await() }
}
