Sprint 2 files. Copy these over your project (same paths):
  firestore.rules                                   -> paste into Firebase Console > Firestore > Rules > Publish
  app/src/main/java/com/sanjeevani/app/MainActivity.kt
  app/src/main/java/com/sanjeevani/app/data/AppRepository.kt          (new)
  app/src/main/java/com/sanjeevani/app/ui/common/Common.kt            (new)
  app/src/main/java/com/sanjeevani/app/ui/user/UserApp.kt             (new)
  app/src/main/java/com/sanjeevani/app/ui/provider/ProviderApp.kt     (new)
Then DELETE the old files:
  ui/user/UserHomeScreen.kt
  ui/provider/ProviderHomeScreen.kt
And add this line in app/build.gradle.kts dependencies:
  implementation("androidx.compose.material:material-icons-core")
Testing a provider: after signing up as Provider, open Firebase Console > Firestore > providers > (your uid)
and set verified = true (temporary, until the admin approval page is built).
